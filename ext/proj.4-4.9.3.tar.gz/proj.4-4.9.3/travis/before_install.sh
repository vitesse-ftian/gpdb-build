#!/bin/bash

pip install --user cpp-coveralls
./travis/docker.sh


