Licenses
========

The CMake source tree is distributed under terms of the BSD 3-Clause license.

This directory contains other license files that need to be packaged with
binary distributions when certain third-party libraries are included.
